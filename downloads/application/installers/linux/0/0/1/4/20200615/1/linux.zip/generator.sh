#!/bin/bash
cd ${PWD}
./jre/bin/java -cp ./bin/core.jar main/java/ForCheckUploads