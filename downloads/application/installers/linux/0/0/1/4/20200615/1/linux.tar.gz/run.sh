#!/bin/bash
cd ${PWD}
if [ -f jre.tar.gz ]; then
    tar zxf jre.tar.gz
    rm jre.tar.gz
fi
./jre/bin/java -jar ./bin/checkUpdates.jar