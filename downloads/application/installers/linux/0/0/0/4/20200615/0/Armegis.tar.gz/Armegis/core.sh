#!/bin/bash
cd ${PWD}
./jre/bin/java -jar ./bin/core.jar