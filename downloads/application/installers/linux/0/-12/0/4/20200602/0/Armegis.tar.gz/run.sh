#!/bin/bash
cd ${PWD}
./jre/bin/java -jar ./bin/checkUpdates.jar